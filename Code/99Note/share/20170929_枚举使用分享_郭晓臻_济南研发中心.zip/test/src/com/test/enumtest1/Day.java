package com.test.enumtest1;

public enum Day {
	MON;
}
