package com.test.enum2;

public enum BasicOperation1 {
	
	PLUS(){
		public int apply(int x,int y){return x+y;}
	},
	
	MINUS(){
		public int apply(int x,int y){return x-y;}
	};
	
	public abstract int apply(int x,int y);
}
