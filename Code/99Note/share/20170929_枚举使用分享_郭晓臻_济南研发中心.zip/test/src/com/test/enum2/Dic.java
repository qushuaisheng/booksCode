package com.test.enum2;

public enum Dic {

	BEIJING("1", "北京"),

	SHAGNHAI("2", "上海"),

	TIANJIN("3", "天津");

	private String value;
	
	private String name;

	private Dic(String value, String name) {
		this.value = value;
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

	public String getValue() {
		return this.value;
	}

	/**
	 * 
	 * @description 根据value获取名称 <br/>
	 * @return
	 */
	public static String getNameByValue(String value) {
		for (Dic it : Dic.values()) {
			if (it.getValue().equals(value)) {
				return it.getName();
			}
		}
		return null;
	}

}
