package com.test;

import java.util.EnumMap;
import java.util.Map;

import com.test.enum2.BasicOperation1;
import com.test.enum2.Regex;
import com.test.enumtest3.BasicOperation2;
import com.test.enumtest3.Operation;

public class Test {
	public static void main(String[] args) {
//		System.out.println(FRUIT.APPLE);
//		System.out.println(BasicOperation.MINUS.apply(0.5, 0.6));
//		System.out.println(FRUIT.APPLE instanceof FRUIT);
//		System.out.println(FRUIT.APPLE instanceof Enum);
//		System.out.println(FRUIT.APPLE instanceof Object);、
		
//		System.out.println("aa" instanceof Object);
//		System.out.println(FRUIT.APPLE.toString());
//		System.out.println(FRUIT.APPLE.name());
//		System.out.println(Fruit.values());
//		System.out.println(Fruit.valueOf("APPLE"));
//		System.out.println(Regex.mobileRegex.islegal("12132123"));
//		System.out.println(Regex.emailRegex.islegal("11qq.com"));
//		System.out.println(Fruit.APPLE == Day.MON);
		
//		System.out.println(BasicOperation1.MINUS.apply(5,6));
//		System.out.println(BasicOperation1.MINUS.apply(5,6));
		  
//		System.out.println(Regex.emailRegex.islegal("adfasdfasfsd@sina.com"));
		
		System.out.println(BasicOperation2.PLUS.apply(10, 5));
		System.out.println(BasicOperation2.MINUS.apply(10, 5));
	}
}

