package com.test.enum2;

import java.util.regex.Pattern;

public enum Regex {

	mobileRegex("^[1]\\d{10}$"),
	
	emailRegex("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$");

	private String regex;

	private Regex(String regex) {
		this.regex = regex;
	}

	public boolean islegal(String value) {
		try {
			return Pattern.matches(regex, value);
		} catch (Exception e) {
			return false;
		}
	}

}
