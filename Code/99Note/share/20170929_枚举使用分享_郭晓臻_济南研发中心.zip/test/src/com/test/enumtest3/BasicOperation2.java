package com.test.enumtest3;

public enum BasicOperation2 implements Operation{
	
	PLUS("+"){
		public int apply(int x,int y){return x+y;}
	},
	
	MINUS("-"){
		public int apply(int x,int y){return x-y;}
	};
	
	private final String symbol;

	private BasicOperation2(String symbol) {
		this.symbol = symbol;
	}
	public String toString() {
		return symbol;
	}
}
