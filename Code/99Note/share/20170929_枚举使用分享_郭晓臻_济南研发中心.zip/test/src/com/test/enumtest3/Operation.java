package com.test.enumtest3;

public interface Operation {
	int apply(int x,int y);
}
