package com.test.enumtest1;

public enum Fruit {
	APPLE,BANANA,ORA;
}
